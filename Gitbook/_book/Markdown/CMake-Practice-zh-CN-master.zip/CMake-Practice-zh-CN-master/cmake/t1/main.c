#include <stdio.h>

int main()
{
    printf("Hello World from t1 Main!\n");
    
    return 0;
}
