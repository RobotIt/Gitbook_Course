#include "hello.h"

void HelloFunc() 
{
    printf("Hello World\n");
}
