#include <hello.h>

int main(void)
{
    HelloFunc();

    return 0;
}
